package com.campusfp.lectura;

import java.util.List;
import com.campusfp.lectura.Item;

public class PruebaLeer extends Thread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaXParser parseLectura = new StaXParser();
		List<Item> solucion = parseLectura.leer("config.xml");
		List<Item> solucion2 = parseLectura.leer("config2.xml");
		
		
		for (Item item : solucion ) {
            System.out.println(item);
        }
		
	}
}
