package com.campusfp.lectura;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

public class StaXParser {
	static final String NOMBRE = "nombre";
	static final String CIUDAD = "ciudad";
	static final String SALARIO = "salario";
	static final String ITEM = "item";

	public List<Item> leer(String archivoxml) {
		List<Item> items = new ArrayList<Item>();

		try {
			XMLInputFactory Factoria = XMLInputFactory.newInstance();
			// ahora ponemos el lector de ficheros
			InputStream entrada = new FileInputStream(archivoxml);
			// ahora vamos a leer el fichero
			XMLEventReader lector = Factoria.createXMLEventReader(entrada);
			Item item = null;
			while (lector.hasNext()) {
				XMLEvent event = lector.nextEvent();
				if (event.isStartElement()) {
					StartElement startElement = event.asStartElement();
					if (startElement.getName().getLocalPart().equals(ITEM)) {
						item = new Item();
					}
					if (event.isStartElement()) {
						if (event.asStartElement().getName().getLocalPart().equals(NOMBRE)) {
							event = lector.nextEvent();
							item.setNombre(event.asCharacters().getData());
							continue;
						}
					}
					if (event.isStartElement()) {
						if (event.asStartElement().getName().getLocalPart().equals(SALARIO)) {
							event = lector.nextEvent();
							item.setSalario(event.asCharacters().getData());
							continue;
						}
					}
					if (event.isStartElement()) {
						if (event.asStartElement().getName().getLocalPart().equals(CIUDAD)) {
							event = lector.nextEvent();
							item.setCiudad(event.asCharacters().getData());
							continue;
						}
					}
					items.add(item);
				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return items;
	}

}
